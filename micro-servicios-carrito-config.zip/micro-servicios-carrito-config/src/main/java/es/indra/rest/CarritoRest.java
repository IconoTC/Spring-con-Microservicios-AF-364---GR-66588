package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.models.Carrito;
import es.indra.service.CarritoService;

@RestController
public class CarritoRest {
	
	@Autowired
	private CarritoService carritoService;
	
	// http://localhost:8003/crear/usuario1
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return carritoService.crear(usuario);
	} 
	
	// http://localhost:8003/agregarPedido/1/cantidad/16/usuario/usuario1
	@PutMapping("/agregarPedido/{id}/cantidad/{cantidad}/usuario/{usuario}")
	public Carrito agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, @PathVariable String usuario) {
		return carritoService.agregarPedido(id, cantidad, usuario);
	} 
	
	// http://localhost:8003/consultar/usuario1
	@GetMapping("/consultar/{usuario}")
	public Carrito consultar(@PathVariable String usuario) {
		return carritoService.consultar(usuario);
	}
	
	// http://localhost:8003/eliminar/1/usuario/usuario1
	@DeleteMapping("/eliminar/{id}/usuario/{usuario}")
	public Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		return carritoService.eliminarPedido(id, usuario);
	}

}
